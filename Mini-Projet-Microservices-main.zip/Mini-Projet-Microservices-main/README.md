# Hospital Microservices Architecture

Projet d'hôpital avec architecture microservices complète utilisant Java 21, Spring Boot 3.3.5, Spring Cloud 2024.0.0 (Moorgate).

## Architecture

### Services d'Infrastructure

1. **Eureka Server** (Port 8761)
   - Service de découverte et registre
   - Dashboard: http://localhost:8761
   - Configuration: `registerWithEureka=false`, `fetchRegistry=false`

2. **Config Server** (Port 8888)
   - Centralisation de la configuration
   - Stockage natif dans `./config`
   - Endpoints: http://localhost:8888/{application}/{profile}

3. **API Gateway** (Port 8080)
   - Point d'entrée unique
   - Routage automatique via Eureka avec paths simples
   - Routes configurées:
     - `/patients/**` → `PATIENT-SERVICE`
     - `/appointments/**` → `APPOINTMENT-SERVICE`
     - `/records/**` → `MEDICAL-RECORD-SERVICE`

### Services Métier

4. **Patient Service** (Port 8081)
   - Gestion CRUD des patients
   - Enregistrement automatique dans Eureka
   - Configuration centralisée via Config Server

5. **Appointment Service** (Port 8082)
   - Gestion des rendez-vous
   - Communication avec Patient Service via Feign
   - Résilience avec Resilience4j

6. **Medical Record Service** (Port 8083)
   - Gestion des dossiers médicaux
   - Communication avec Patient Service via Feign
   - Résilience avec Resilience4j

## Technologies

- **Java 21**
- **Spring Boot 3.3.5**
- **Spring Cloud 2024.0.0 (Moorgate)**
- **Spring Cloud Netflix** (Eureka, Feign)
- **Spring Cloud Gateway**
- **Spring Cloud Config**
- **Resilience4j** (CircuitBreaker, Retry, Timeout, Fallback)
- **Maven Daemon 1.0.3**
- **Lombok**
- **H2 Database** (in-memory)
- **Spring Data JPA**

## Démarrage

### Prérequis

- Java 21
- Maven Daemon 1.0.3+

### Ordre de démarrage

Ouvrez 6 terminaux distincts et lancez les services dans cet ordre:

1. **Config Server**
```bash
cd config-server
mvnd spring-boot:run
```

2. **Eureka Server**
```bash
cd eureka-server
mvnd spring-boot:run
```

3. **API Gateway**
```bash
cd api-gateway
mvnd spring-boot:run
```

4. **Patient Service**
```bash
cd patient-service
mvnd spring-boot:run
```

5. **Appointment Service**
```bash
cd appointment-service
mvnd spring-boot:run
```

6. **Medical Record Service**
```bash
cd medical-record-service
mvnd spring-boot:run
```

## Test via API Gateway

### 1. Créer un patient
```bash
curl -X POST http://localhost:8081/patients \
  -H "Content-Type: application/json" \
  -d '{
    "nom": "Dupont",
    "prenom": "Jean",
    "dateNaissance": "1990-01-15",
    "contact": "0123456789"
  }'
```

### 2. Lister les patients
```bash
curl http://localhost:8081/patients
```

### 3. Créer un rendez-vous
```bash
curl -X POST http://localhost:8082/appointments \
  -H "Content-Type: application/json" \
  -d '{
    "patientId": 1,
    "dateHeure": "2026-02-20T10:30:00",
    "motif": "Consultation g\u00e9n\u00e9rale"
  }'
```

### 4. Lister les rendez-vous d'un patient
```bash
curl http://localhost:8082/appointments/patient/1
```

### 5. Créer un dossier médical
```bash
curl -X POST http://localhost:8083/records \
  -H "Content-Type: application/json" \
  -d '{
    "patientId": 1,
    "diagnostics": "Hypertension l\u00e9g\u00e8re",
    "historique": "Patient \u00e0 surveiller, premier diagnostic"
  }'
```

### 6. Lister les dossiers médicaux d'un patient
```bash
curl http://localhost:8083/records/patient/1
```

## Vider les données (reset)

Supprime toutes les données (H2 en mémoire) via les endpoints DELETE:

```bash
curl -X DELETE http://localhost:8083/records
curl -X DELETE http://localhost:8082/appointments
curl -X DELETE http://localhost:8081/patients
```

One-liner:

```bash
curl -X DELETE http://localhost:8083/records && curl -X DELETE http://localhost:8082/appointments && curl -X DELETE http://localhost:8081/patients
```

Vérifier que c'est vide:

```bash
curl http://localhost:8081/patients
curl http://localhost:8082/appointments
curl http://localhost:8083/records
```

## Démonstration de la Résilience

### Test du Circuit Breaker et Fallback

1. **Arrêtez le Patient Service** (Ctrl+C dans le terminal du patient-service)

2. **Essayez de créer un rendez-vous**:
```bash
curl -X POST http://localhost:8082/appointments \
  -H "Content-Type: application/json" \
  -d '{
    "patientId": 1,
    "dateHeure": "2026-02-20T10:30:00",
    "motif": "Consultation g\u00e9n\u00e9rale"
  }'
```

3. **Résultat attendu**: Le rendez-vous sera créé malgré l'indisponibilité du service Patient, grâce au fallback.

4. **Vérifiez les logs** du appointment-service pour voir le message:
```
Patient service indisponible, création du rendez-vous sans vérification
```

5. **Redémarrez le Patient Service** et réessayez pour voir le retour à la normale.

## Surveillance

### Eureka Dashboard
- URL: http://localhost:8761
- Affiche tous les services enregistrés
- État de santé des instances

### Config Server
- URL: http://localhost:8888
- Accès aux configurations:
  - http://localhost:8888/PATIENT-SERVICE/default
  - http://localhost:8888/APPOINTMENT-SERVICE/default
  - http://localhost:8888/MEDICAL-RECORD-SERVICE/default

### Console H2
Chaque service expose sa console H2 sur un port fixe:
- Patient Service: http://localhost:8081/h2-console (JDBC: `jdbc:h2:mem:testdb`)
- Appointment Service: http://localhost:8082/h2-console (JDBC: `jdbc:h2:mem:testdb`)
- Medical Record Service: http://localhost:8083/h2-console (JDBC: `jdbc:h2:mem:testdb`)

**Important**: Dans la console H2, utilisez exactement cette URL JDBC:
```
jdbc:h2:mem:testdb
```

Identifiants:
- URL: `jdbc:h2:mem:testdb`
- Username: `sa`
- Password: `password`

## Configuration de la Résilience

Les services Appointment et Medical Record utilisent Resilience4j:
- **Circuit Breaker**: Se déclenche après 50% d'échecs sur 10 appels
- **Retry**: 3 tentatives avec 1 seconde d'attente
- **Timeout**: 3 secondes maximum par appel
- **Fallback**: Crée l'entité sans vérification du patient si le service est indisponible
- **Instance Name**: `patientService` (utilisé pour la communication avec le Patient Service)

## Architecture de Configuration

- **application.yml**: Configuration par défaut commune
- **{SERVICE-NAME}.yml**: Configuration spécifique à chaque service
- Les services récupèrent leur configuration au démarrage depuis le Config Server

## Endpoints API

### Patients (via Gateway - Port 8080)
- `POST /patients` - Créer un patient
- `GET /patients` - Lister tous les patients
- `GET /patients/{id}` - Récupérer un patient

### Rendez-vous (via Gateway - Port 8080)
- `POST /appointments` - Créer un rendez-vous
- `GET /appointments/patient/{patientId}` - Lister les rendez-vous d'un patient

### Dossiers Médicaux (via Gateway - Port 8080)
- `POST /records` - Créer un dossier médical
- `GET /records/patient/{patientId}` - Lister les dossiers d'un patient

## Test Rapide

Pour tester rapidement toute l'architecture, exécutez le script fourni:
```bash
PowerShell -ExecutionPolicy Bypass -File test-gateway.ps1
```

Ce script vérifie:
- L'enregistrement des services dans Eureka
- Le routage via l'API Gateway
- La création et la récupération de données pour chaque service

## Notes

- Les services métier utilisent des ports fixes: Patient Service (8081), Appointment Service (8082), Medical Record Service (8083)
- L'API Gateway est le seul point d'entrée externe sur le port 8080
- La communication inter-services utilise Eureka pour la découverte
- Les routes du Gateway utilisent des paths simples: `/patients`, `/appointments`, `/records`
- La configuration est centralisée et gérée dynamiquement
- Chaque service a sa propre base de données H2 en mémoire
- Pas d'authentification implémentée (comme demandé)
- Pas de frontend (comme demandé)
- Les commentaires sont en français quand possible

## Dépannage

### Problèmes courants

1. **Services ne s'enregistrent pas dans Eureka**
   - Vérifiez que Eureka Server est démarré en premier
   - Vérifiez les configurations `eureka.client.service-url.defaultZone`

2. **Configuration non chargée depuis Config Server**
   - Vérifiez que Config Server est démarré
   - Vérifiez les fichiers dans `config-server/config/`

3. **Routage Gateway ne fonctionne pas**
   - Vérifiez que les services sont enregistrés dans Eureka
   - Vérifiez la configuration des routes dans `api-gateway/application.yml`

4. **Circuit Breaker ne se déclenche pas**
   - Vérifiez la configuration Resilience4j
   - Consultez les logs pour voir les tentatives de retry

---



**💡 RAPPEL: Ordre de démarrage recommandé → Eureka → Config Server → Gateway → Services métier**
