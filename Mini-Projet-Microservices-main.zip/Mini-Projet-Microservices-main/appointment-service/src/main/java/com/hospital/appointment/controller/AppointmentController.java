package com.hospital.appointment.controller;

import com.hospital.appointment.model.Appointment;
import com.hospital.appointment.service.AppointmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Contrôleur REST pour la gestion des rendez-vous
 * Expose les endpoints pour créer et lister les rendez-vous
 */
@RestController
@RequestMapping("/appointments")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AppointmentController {
    
    private final AppointmentService appointmentService;
    
    /**
     * Crée un nouveau rendez-vous
     * @param appointment le rendez-vous à créer
     * @return le rendez-vous créé ou erreur
     */
    @PostMapping
    public ResponseEntity<?> createAppointment(@RequestBody Appointment appointment) {
        try {
            Appointment createdAppointment = appointmentService.createAppointment(appointment);
            return new ResponseEntity<>(createdAppointment, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            if (e.getMessage().contains("Patient inexistant")) {
                return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>("Erreur lors de la création du rendez-vous", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Liste tous les rendez-vous
     * @return la liste de tous les rendez-vous
     */
    @GetMapping
    public ResponseEntity<List<Appointment>> getAllAppointments() {
        List<Appointment> appointments = appointmentService.getAllAppointments();
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }
    
    /**
     * Récupère les rendez-vous d'un patient spécifique
     * @param patientId l'ID du patient
     * @return la liste des rendez-vous du patient
     */
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByPatient(@PathVariable Long patientId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByPatient(patientId);
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }
    
    /**
     * Supprime un rendez-vous par son ID
     * @param id l'ID du rendez-vous à supprimer
     * @return 200 si succès, 404 si non trouvé
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable Long id) {
        if (appointmentService.getAppointmentById(id).isPresent()) {
            appointmentService.deleteAppointment(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    
    /**
     * Supprime tous les rendez-vous
     * @return 200 si succès
     */
    @DeleteMapping
    public ResponseEntity<Void> deleteAllAppointments() {
        appointmentService.deleteAllAppointments();
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
