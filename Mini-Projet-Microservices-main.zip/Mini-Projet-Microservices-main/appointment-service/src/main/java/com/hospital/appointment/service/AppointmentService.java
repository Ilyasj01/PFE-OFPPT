package com.hospital.appointment.service;

import com.hospital.appointment.client.PatientClient;
import com.hospital.appointment.dto.PatientDto;
import com.hospital.appointment.model.Appointment;
import com.hospital.appointment.repository.AppointmentRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service de gestion des rendez-vous
 * Implémente la logique métier avec vérification du patient via Feign
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AppointmentService {
    
    private final AppointmentRepository appointmentRepository;
    private final PatientClient patientClient;
    
    /**
     * Crée un nouveau rendez-vous
     * Vérifie d'abord que le patient existe
     * @param appointment le rendez-vous à créer
     * @return le rendez-vous créé
     */
    @CircuitBreaker(name = "patientService", fallbackMethod = "fallback")
    public Appointment createAppointment(Appointment appointment) {
        // Vérifier si le patient existe via le service Patient
        PatientDto patient = patientClient.getPatient(appointment.getPatientId());
        if (patient == null) {
            throw new RuntimeException("Patient inexistant");
        }
        
        return appointmentRepository.save(appointment);
    }
    
    /**
     * Méthode fallback pour le circuit breaker
     * @param appointment le rendez-vous à créer
     * @param throwable l'exception levée
     * @return le rendez-vous créé avec message d'avertissement
     */
    public Appointment fallback(Appointment appointment, Throwable throwable) {
        log.warn("Patient service indisponible, création du rendez-vous sans vérification: {}", throwable.getMessage());
        // Créer le rendez-vous sans vérification du patient
        return appointmentRepository.save(appointment);
    }
    
    /**
     * Récupère les rendez-vous d'un patient
     * @param patientId l'ID du patient
     * @return la liste des rendez-vous du patient
     */
    public List<Appointment> getAppointmentsByPatient(Long patientId) {
        return appointmentRepository.findByPatientIdOrderByDateHeureDesc(patientId);
    }
    
    /**
     * Récupère tous les rendez-vous
     * @return la liste des rendez-vous
     */
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }
    
    /**
     * Récupère un rendez-vous par son ID
     * @param id l'ID du rendez-vous
     * @return le rendez-vous trouvé ou empty
     */
    public Optional<Appointment> getAppointmentById(Long id) {
        return appointmentRepository.findById(id);
    }
    
    /**
     * Supprime un rendez-vous par son ID
     * @param id l'ID du rendez-vous à supprimer
     */
    public void deleteAppointment(Long id) {
        if (!appointmentRepository.existsById(id)) {
            throw new IllegalArgumentException("Rendez-vous non trouvé avec l'ID: " + id);
        }
        appointmentRepository.deleteById(id);
    }
    
    /**
     * Supprime tous les rendez-vous
     */
    public void deleteAllAppointments() {
        appointmentRepository.deleteAll();
    }
}
