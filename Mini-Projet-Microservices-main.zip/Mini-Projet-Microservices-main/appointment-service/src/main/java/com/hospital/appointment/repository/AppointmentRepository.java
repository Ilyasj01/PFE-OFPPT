package com.hospital.appointment.repository;

import com.hospital.appointment.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository pour l'entité Appointment
 * Fournit les opérations de base pour la gestion des rendez-vous
 */
@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    
    /**
     * Recherche les rendez-vous par ID de patient
     * @param patientId l'ID du patient
     * @return la liste des rendez-vous du patient
     */
    List<Appointment> findByPatientIdOrderByDateHeureDesc(Long patientId);
}
