package com.hospital.medicalrecord.service;

import com.hospital.medicalrecord.client.PatientClient;
import com.hospital.medicalrecord.dto.PatientDto;
import com.hospital.medicalrecord.model.MedicalRecord;
import com.hospital.medicalrecord.repository.MedicalRecordRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service de gestion des dossiers médicaux
 * Implémente la logique métier avec vérification du patient via Feign
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MedicalRecordService {
    
    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientClient patientClient;
    
    /**
     * Crée un nouveau dossier médical
     * Vérifie d'abord que le patient existe
     * @param medicalRecord le dossier médical à créer
     * @return le dossier médical créé
     */
    @CircuitBreaker(name = "patientService", fallbackMethod = "fallback")
    public MedicalRecord createMedicalRecord(MedicalRecord medicalRecord) {
        // Vérifier si le patient existe via le service Patient
        PatientDto patient = patientClient.getPatient(medicalRecord.getPatientId());
        if (patient == null) {
            throw new RuntimeException("Patient inexistant");
        }
        
        return medicalRecordRepository.save(medicalRecord);
    }
    
    /**
     * Méthode fallback pour le circuit breaker
     * @param medicalRecord le dossier médical à créer
     * @param throwable l'exception levée
     * @return le dossier médical créé avec message d'avertissement
     */
    public MedicalRecord fallback(MedicalRecord medicalRecord, Throwable throwable) {
        log.warn("Patient service indisponible, création du dossier médical sans vérification: {}", throwable.getMessage());
        // Créer le dossier médical sans vérification du patient
        return medicalRecordRepository.save(medicalRecord);
    }
    
    /**
     * Récupère les dossiers médicaux d'un patient
     * @param patientId l'ID du patient
     * @return la liste des dossiers médicaux du patient
     */
    public List<MedicalRecord> getMedicalRecordsByPatient(Long patientId) {
        return medicalRecordRepository.findByPatientIdOrderByIdDesc(patientId);
    }
    
    /**
     * Récupère tous les dossiers médicaux
     * @return la liste des dossiers médicaux
     */
    public List<MedicalRecord> getAllMedicalRecords() {
        return medicalRecordRepository.findAll();
    }
    
    /**
     * Récupère un dossier médical par son ID
     * @param id l'ID du dossier médical
     * @return le dossier médical trouvé ou empty
     */
    public Optional<MedicalRecord> getMedicalRecordById(Long id) {
        return medicalRecordRepository.findById(id);
    }
    
    /**
     * Supprime un dossier médical par son ID
     * @param id l'ID du dossier médical à supprimer
     */
    public void deleteMedicalRecord(Long id) {
        if (!medicalRecordRepository.existsById(id)) {
            throw new IllegalArgumentException("Dossier médical non trouvé avec l'ID: " + id);
        }
        medicalRecordRepository.deleteById(id);
    }
    
    /**
     * Supprime tous les dossiers médicaux
     */
    public void deleteAllMedicalRecords() {
        medicalRecordRepository.deleteAll();
    }
}
