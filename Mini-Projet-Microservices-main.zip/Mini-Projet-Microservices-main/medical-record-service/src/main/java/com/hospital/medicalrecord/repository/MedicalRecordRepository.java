package com.hospital.medicalrecord.repository;

import com.hospital.medicalrecord.model.MedicalRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository pour l'entité MedicalRecord
 * Fournit les opérations de base pour la gestion des dossiers médicaux
 */
@Repository
public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Long> {
    
    /**
     * Recherche les dossiers médicaux par ID de patient
     * @param patientId l'ID du patient
     * @return la liste des dossiers médicaux du patient
     */
    List<MedicalRecord> findByPatientIdOrderByIdDesc(Long patientId);
}
