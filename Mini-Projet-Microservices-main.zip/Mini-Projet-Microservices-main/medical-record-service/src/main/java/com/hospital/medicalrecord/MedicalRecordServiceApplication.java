package com.hospital.medicalrecord;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Classe principale du Service des Dossiers Médicaux
 * Démarrage du microservice de gestion des dossiers médicaux
 */
@SpringBootApplication
@EnableFeignClients
public class MedicalRecordServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(MedicalRecordServiceApplication.class, args);
    }
}
