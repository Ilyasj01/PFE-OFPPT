package com.hospital.medicalrecord.client;

import com.hospital.medicalrecord.dto.PatientDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Fallback pour le PatientClient
 * Utilisé quand le service Patient est indisponible
 */
@Component
public class PatientFallback implements PatientClient {
    
    private static final Logger log = LoggerFactory.getLogger(PatientFallback.class);

    @Override
    public PatientDto getPatient(Long id) {
        log.warn("Patient service unavailable, returning fallback for id {}", id);
        // Retourner un patient par défaut pour le fallback
        PatientDto fallbackPatient = new PatientDto();
        fallbackPatient.setId(id);
        fallbackPatient.setNom("Service Indisponible");
        fallbackPatient.setPrenom("Fallback");
        return fallbackPatient;
    }
}
