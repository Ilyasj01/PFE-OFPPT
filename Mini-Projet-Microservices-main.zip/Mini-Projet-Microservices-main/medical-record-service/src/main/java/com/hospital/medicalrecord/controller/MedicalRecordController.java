package com.hospital.medicalrecord.controller;

import com.hospital.medicalrecord.model.MedicalRecord;
import com.hospital.medicalrecord.service.MedicalRecordService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Contrôleur REST pour la gestion des dossiers médicaux
 * Expose les endpoints pour créer et lister les dossiers médicaux
 */
@RestController
@RequestMapping("/records")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class MedicalRecordController {
    
    private final MedicalRecordService medicalRecordService;
    
    /**
     * Crée un nouveau dossier médical
     * @param medicalRecord le dossier médical à créer
     * @return le dossier médical créé ou erreur
     */
    @PostMapping
    public ResponseEntity<?> createMedicalRecord(@RequestBody MedicalRecord medicalRecord) {
        try {
            MedicalRecord createdRecord = medicalRecordService.createMedicalRecord(medicalRecord);
            return new ResponseEntity<>(createdRecord, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            if (e.getMessage().contains("Patient inexistant")) {
                return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>("Erreur lors de la création du dossier médical", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Liste tous les dossiers médicaux
     * @return la liste de tous les dossiers médicaux
     */
    @GetMapping
    public ResponseEntity<List<MedicalRecord>> getAllMedicalRecords() {
        List<MedicalRecord> records = medicalRecordService.getAllMedicalRecords();
        return new ResponseEntity<>(records, HttpStatus.OK);
    }
    
    /**
     * Récupère les dossiers médicaux d'un patient spécifique
     * @param patientId l'ID du patient
     * @return la liste des dossiers médicaux du patient
     */
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<MedicalRecord>> getMedicalRecordsByPatient(@PathVariable Long patientId) {
        List<MedicalRecord> records = medicalRecordService.getMedicalRecordsByPatient(patientId);
        return new ResponseEntity<>(records, HttpStatus.OK);
    }
    
    /**
     * Supprime un dossier médical par son ID
     * @param id l'ID du dossier médical à supprimer
     * @return 200 si succès, 404 si non trouvé
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMedicalRecord(@PathVariable Long id) {
        if (medicalRecordService.getMedicalRecordById(id).isPresent()) {
            medicalRecordService.deleteMedicalRecord(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    
    /**
     * Supprime tous les dossiers médicaux
     * @return 200 si succès
     */
    @DeleteMapping
    public ResponseEntity<Void> deleteAllMedicalRecords() {
        medicalRecordService.deleteAllMedicalRecords();
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
