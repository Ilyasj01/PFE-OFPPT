package com.hospital.medicalrecord.client;

import com.hospital.medicalrecord.dto.PatientDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Client Feign pour communiquer avec le service Patient
 */
@FeignClient(name = "PATIENT-SERVICE", fallback = PatientFallback.class)
public interface PatientClient {
    
    /**
     * Récupère un patient par son ID
     * @param id l'ID du patient
     * @return le patient trouvé
     */
    @GetMapping("/patients/{id}")
    PatientDto getPatient(@PathVariable("id") Long id);
}
