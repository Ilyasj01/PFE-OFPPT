package com.hospital.medicalrecord.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO pour les informations du patient
 * Utilisé pour les échanges avec le service Patient
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientDto {
    
    private Long id;
    private String nom;
    private String prenom;
}
