package com.hospital.patient.service;

import com.hospital.patient.model.Patient;
import com.hospital.patient.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service de gestion des patients
 * Implémente la logique métier pour les opérations CRUD
 */
@Service
@RequiredArgsConstructor
public class PatientService {
    
    private final PatientRepository patientRepository;
    
    /**
     * Crée un nouveau patient
     * @param patient le patient à créer
     * @return le patient créé
     */
    public Patient createPatient(Patient patient) {
        return patientRepository.save(patient);
    }
    
    /**
     * Récupère tous les patients
     * @return la liste des patients
     */
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }
    
    /**
     * Récupère un patient par son ID
     * @param id l'ID du patient
     * @return le patient trouvé ou empty
     */
    public Optional<Patient> getPatientById(Long id) {
        return patientRepository.findById(id);
    }
    
    /**
     * Met à jour un patient existant
     * @param id l'ID du patient à mettre à jour
     * @param patientDetails les nouvelles informations du patient
     * @return le patient mis à jour
     */
    public Patient updatePatient(Long id, Patient patientDetails) {
        return patientRepository.findById(id)
                .map(patient -> {
                    patient.setNom(patientDetails.getNom());
                    patient.setPrenom(patientDetails.getPrenom());
                    patient.setDateNaissance(patientDetails.getDateNaissance());
                    patient.setContact(patientDetails.getContact());
                    return patientRepository.save(patient);
                })
                .orElseThrow(() -> new IllegalArgumentException("Patient non trouvé avec l'ID: " + id));
    }
    
    /**
     * Supprime un patient par son ID
     * @param id l'ID du patient à supprimer
     */
    public void deletePatient(Long id) {
        if (!patientRepository.existsById(id)) {
            throw new IllegalArgumentException("Patient non trouvé avec l'ID: " + id);
        }
        patientRepository.deleteById(id);
    }
    
    /**
     * Supprime tous les patients
     */
    public void deleteAllPatients() {
        patientRepository.deleteAll();
    }
}
