package com.hospital.patient.repository;

import com.hospital.patient.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository pour l'entité Patient
 * Fournit les opérations de base pour la gestion des patients
 */
@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {
}
